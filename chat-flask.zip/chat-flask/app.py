from flask import Flask, render_template, request, jsonify
from openai import OpenAI

# ⚠️ Keep private
OPENROUTER_API_KEY = "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"

client = OpenAI(
    base_url="https://openrouter.ai/api/v1",
    api_key=OPENROUTER_API_KEY,
)

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    data = request.get_json()
    user_message = data.get("message", "")

    try:
        response = client.chat.completions.create(
            model="openai/gpt-4o",
            messages=[
                {"role": "system", "content": "You are a skilled AI assistant who gives clear, well-formatted answers with code examples when relevant."},
                {"role": "user", "content": user_message}
            ],
        )
        ai_reply = response.choices[0].message.content
    except Exception as e:
        ai_reply = f"Error: {str(e)}"

    return jsonify({"reply": ai_reply})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
