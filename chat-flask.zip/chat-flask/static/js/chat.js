class ChatBot {
    constructor() {
        this.chatBox = document.getElementById('chat-box');
        this.userInput = document.getElementById('user-input');
        this.sendBtn = document.getElementById('send-btn');
        this.typingIndicator = document.getElementById('typing-indicator');
        this.clearChatBtn = document.getElementById('clear-chat');

        this.initEventListeners();
        this.loadChatHistory();
    }

    initEventListeners() {
        this.sendBtn.addEventListener('click', () => this.sendMessage());
        this.userInput.addEventListener('keypress', (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                this.sendMessage();
            }
        });

        this.clearChatBtn.addEventListener('click', () => this.clearChat());

        // Auto-resize input
        this.userInput.addEventListener('input', () => {
            this.userInput.style.height = 'auto';
            this.userInput.style.height = Math.min(this.userInput.scrollHeight, 120) + 'px';
        });
    }

    async sendMessage() {
        const message = this.userInput.value.trim();
        if (!message) return;

        this.addMessage(message, 'user');
        this.userInput.value = '';
        this.userInput.style.height = 'auto';
        this.showTyping();

        try {
            const response = await fetch('/chat', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ message })
            });

            const data = await response.json();
            this.hideTyping();
            this.addMessage(data.reply, 'bot');
        } catch (error) {
            this.hideTyping();
            this.addMessage('Sorry, I encountered an error. Please try again.', 'bot');
            console.error('Error:', error);
        }

        this.saveChatHistory();
        this.scrollToBottom();
    }

    addMessage(content, sender) {
        const messageDiv = document.createElement('div');
        messageDiv.className = `message ${sender}`;

        const avatar = sender === 'user' ?
            '<div class="avatar"><i class="fas fa-user"></i></div>' :
            '<div class="avatar"><i class="fas fa-robot"></i></div>';

        const formattedContent = this.formatMessage(content);
        const timestamp = this.getCurrentTime();

        messageDiv.innerHTML = `
            ${avatar}
            <div class="message-content">
                <div class="bubble">${formattedContent}</div>
                <div class="message-time">${timestamp}</div>
            </div>
        `;

        this.chatBox.appendChild(messageDiv);
        this.scrollToBottom();
    }

    formatMessage(content) {
        // Convert markdown code blocks to formatted HTML
        let formatted = content
            .replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
                const language = lang || 'text';
                return `
                    <div class="code-block">
                        <div class="code-header">
                            <span class="code-language">${language}</span>
                            <button class="copy-btn" onclick="copyCode(this)">
                                <i class="far fa-copy"></i>
                                Copy
                            </button>
                        </div>
                        <div class="code-content">
                            <pre>${this.escapeHtml(code.trim())}</pre>
                        </div>
                    </div>
                `;
            })
            .replace(/`([^`]+)`/g, '<code>$1</code>')
            .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
            .replace(/\*(.*?)\*/g, '<em>$1</em>')
            .replace(/\n/g, '<br>');

        return formatted;
    }

    escapeHtml(unsafe) {
        return unsafe
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    }

    showTyping() {
        this.typingIndicator.style.display = 'flex';
        this.scrollToBottom();
    }

    hideTyping() {
        this.typingIndicator.style.display = 'none';
    }

    scrollToBottom() {
        setTimeout(() => {
            this.chatBox.scrollTop = this.chatBox.scrollHeight;
        }, 100);
    }

    getCurrentTime() {
        return new Date().toLocaleTimeString([], {
            hour: '2-digit',
            minute: '2-digit'
        });
    }

    clearChat() {
        if (confirm('Are you sure you want to clear the chat?')) {
            this.chatBox.innerHTML = `
                <div class="message bot">
                    <div class="avatar">
                        <i class="fas fa-robot"></i>
                    </div>
                    <div class="message-content">
                        <div class="bubble">
                            👋 Hello! I'm your AI assistant. How can I help you today?
                        </div>
                        <div class="message-time">Just now</div>
                    </div>
                </div>
            `;
            localStorage.removeItem('chatHistory');
        }
    }

    saveChatHistory() {
        const messages = Array.from(this.chatBox.children).map(msg => ({
            html: msg.outerHTML,
            sender: msg.classList.contains('user') ? 'user' : 'bot'
        }));
        localStorage.setItem('chatHistory', JSON.stringify(messages));
    }

    loadChatHistory() {
        const saved = localStorage.getItem('chatHistory');
        if (saved) {
            const messages = JSON.parse(saved);
            this.chatBox.innerHTML = messages.map(msg => msg.html).join('');
            this.scrollToBottom();
        }
    }
}

// Global function for copy button
function copyCode(button) {
    const codeBlock = button.closest('.code-block');
    const codeContent = codeBlock.querySelector('.code-content pre');
    const text = codeContent.textContent;

    navigator.clipboard.writeText(text).then(() => {
        const originalText = button.innerHTML;
        button.innerHTML = '<i class="fas fa-check"></i> Copied!';
        button.classList.add('copied');

        setTimeout(() => {
            button.innerHTML = originalText;
            button.classList.remove('copied');
        }, 2000);
    });
}

// Initialize chatbot when page loads
document.addEventListener('DOMContentLoaded', () => {
    new ChatBot();
});